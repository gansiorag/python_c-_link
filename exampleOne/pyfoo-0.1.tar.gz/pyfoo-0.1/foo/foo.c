#include <string.h>

#include "foo.h"

int foo(char* str) {
        return strlen(str) * 2;
}