#ifndef FOO_LIB
#define FOO_LIB

int foo(char* str);

#endif