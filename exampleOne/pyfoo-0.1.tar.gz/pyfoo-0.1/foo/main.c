#include <stdio.h>

#include "foo.h"

int main(int argc, char* argv[]) {
        char* str = "0123456789";
        printf("%d\n", foo(str));
}